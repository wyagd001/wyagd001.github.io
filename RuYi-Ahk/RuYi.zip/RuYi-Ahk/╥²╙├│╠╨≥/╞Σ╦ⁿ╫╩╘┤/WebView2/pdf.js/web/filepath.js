﻿document.addEventListener("webviewerloaded", function() {
    PDFViewerApplicationOptions.set("defaultUrl", "file:///文件路径");
        });