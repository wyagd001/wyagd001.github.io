config = {
  "fontSize": 1,
  "clickTab": 0,
  "displaySidebar": true,
  "colorTheme": 0,
  "collapseQuickRef": 1
}
