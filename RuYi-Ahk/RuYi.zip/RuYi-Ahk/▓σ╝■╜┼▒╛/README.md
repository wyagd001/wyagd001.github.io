﻿该文件夹下的脚本为 [如一.exe] 内置的简单动作, 利用Ahk_H的dll文件引入多线程.
OnMessage(0x4a, "Receive_WM_COPYDATA") 执行一次后, 响应 如一.exe 发来的消息.